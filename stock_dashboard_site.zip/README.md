# Blake's Long-Term Stock Dashboard

This is a polished static stock dashboard designed for GitHub Pages.

## Files

- `index.html` — the full website in one file.
- `README.md` — setup and update instructions.

## How to publish on GitHub Pages

1. Create a GitHub repository named `stock-dashboard`.
2. Make it public.
3. Click **Add file** → **Upload files**.
4. Upload `index.html`.
5. Click **Commit changes**.
6. Go to **Settings** → **Pages**.
7. Under **Build and deployment**, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ root`
8. Click **Save**.

Your site will be available at:

`https://YOUR-GITHUB-USERNAME.github.io/stock-dashboard/`

## How to update every Monday and Thursday

After each ChatGPT report, ask:

> Give me the Website Update Block for my dashboard.

Then:

1. Open `index.html` in GitHub.
2. Click the pencil icon to edit.
3. Find the section that starts with:
   `const report = {`
4. Replace the old report object with the new Website Update Block.
5. Click **Commit changes**.

## What the site includes

- Market status hero card
- Summary cards
- Valuation scoreboard
- Filters for undervalued / fair / overvalued / new ideas / core
- Score chart
- Undervalued watchlist
- 3 new stock ideas
- Deep valuation reason cards
- Research-method section

## Important note

The sample data inside the website is placeholder/sample content. Always replace it with current Monday/Thursday research data before using it to make investment decisions.
